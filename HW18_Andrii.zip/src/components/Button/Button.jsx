import "./styles.css";

function Button({ name, type }) {
  return <button className={` ${type}`}>{name}</button>;
}
// const Button = ({ name, type }) => {
//   return (
//     <button className={`button ${type}`}>
//       {name}
//     </button>
//   );
// };

export default Button;
