import "./styles.css";
import LoginForm from "../../components/LoginForm/LoginForm";

function Homework18() {
  return (
    <div>
      <LoginForm />
    </div>
  );
}

export default Homework18;
